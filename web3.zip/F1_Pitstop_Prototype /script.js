let web3, contract;
const connectWalletButton = document.getElementById("connectWallet");
const walletAddressEl = document.getElementById("walletAddress");
const networkEl = document.getElementById("network");
const statusEl = document.getElementById("status");
const simulateAttackButton = document.getElementById("simulateAttack");
const attackResult = document.getElementById("attackResult");
const pitstopTable = document.getElementById("pitstopTable");
const txInfo = document.getElementById("txInfo");

// ======= REPLACE THESE TWO with your contract values after deploy =======
const CONTRACT_ADDRESS = "0xPASTE_YOUR_CONTRACT_ADDRESS_HERE";
const CONTRACT_ABI = [ /* PASTE ABI JSON ARRAY HERE */ ];
// =======================================================================

// helper to render table rows
function renderPitstops(list){
  pitstopTable.innerHTML = "<tr><th>Car</th><th>Lap</th><th>Tire</th><th>Fuel</th><th>Time</th></tr>";
  list.forEach(p=>{
    const time = (p.timestamp) ? new Date(p.timestamp*1000).toLocaleTimeString() : new Date().toLocaleTimeString();
    pitstopTable.innerHTML += `<tr><td>${p.carId}</td><td>${p.lapNumber}</td><td>${p.tireType}</td><td>${p.fuelStatus}</td><td>${time}</td></tr>`;
  });
}

// mock initial rows (so UI looks full)
renderPitstops([
  {carId:44,lapNumber:35,tireType:"Medium",fuelStatus:"82%",timestamp:Math.floor(Date.now()/1000)-60},
  {carId:33,lapNumber:34,tireType:"Hard",fuelStatus:"90%",timestamp:Math.floor(Date.now()/1000)-120}
]);

// --------- Connect Wallet -----------
async function connectWallet(){
  if(!window.ethereum){ alert("Install MetaMask"); return; }
  web3 = new Web3(window.ethereum);
  try{
    await window.ethereum.request({method:"eth_requestAccounts"});
    const accounts = await web3.eth.getAccounts();
    walletAddressEl.textContent = "Wallet: " + accounts[0];
    const networkId = await web3.eth.net.getId();
    networkEl.textContent = networkId===11155111 ? "Sepolia" : `Network ID ${networkId}`;
    // initialize contract if ABI present
    if(CONTRACT_ADDRESS && CONTRACT_ABI.length) {
      contract = new web3.eth.Contract(CONTRACT_ABI, CONTRACT_ADDRESS);
      await loadPitstopsFromChain();
    } else {
      statusEl.textContent = "Status: Contract not wired (mock mode)";
    }
  } catch(e){ console.error(e); }
}
connectWalletButton.onclick = connectWallet;

// --------- Real on-chain read - load pitstops ----------
async function loadPitstopsFromChain(){
  if(!contract) return;
  try{
    const list = await contract.methods.getAllPitstops().call();
    // contract may return array of structs; ensure shape fits
    renderPitstops(list);
    statusEl.textContent = "Status: Loaded on-chain pitstops";
  } catch(e){ console.error("read failed", e); statusEl.textContent="Status: read failed"; }
}

// --------- Real on-chain write - addPitstop -----------
async function addPitstopOnChain(carId, lapNumber, tireType, fuelStatus){
  if(!contract || !web3) { alert("Contract not connected. If you want to demo real chain, paste ABI+ADDR"); return; }
  const accounts = await web3.eth.getAccounts();
  txInfo.innerHTML = "Sending tx to chain...";
  try {
    const tx = await contract.methods.addPitstop(carId, lapNumber, tireType, fuelStatus).send({from: accounts[0]});
    txInfo.innerHTML = `Tx confirmed: <a target="_blank" href="https://sepolia.etherscan.io/tx/${tx.transactionHash}">${tx.transactionHash}</a>`;
    await loadPitstopsFromChain();
  } catch(err){
    console.error(err);
    txInfo.textContent = "Tx failed or rejected";
  }
}

// wire button
document.getElementById("addPitstopBtn").addEventListener("click", async ()=>{
  const carId = parseInt(document.getElementById("carId").value);
  const lap = parseInt(document.getElementById("lapNumber").value);
  const tire = document.getElementById("tireType").value;
  const fuel = document.getElementById("fuelStatus").value;
  // if contract not present, simulate a fast mock update for the video
  if(!(CONTRACT_ADDRESS && CONTRACT_ABI.length)){
    // push mock row and show fake tx id
    const newRow = {carId,lapNumber:lap,tireType:tire,fuelStatus:fuel,timestamp:Math.floor(Date.now()/1000)};
    const cur = []; document.querySelectorAll("#pitstopTable tr").forEach((r,i)=>{ if(i>0) cur.push(r); });
    renderPitstops([newRow, ...[]]); // for the demo we just render the new row
    txInfo.innerHTML = `Simulated tx: 0xSIMULATED12345 (mock)`;
    return;
  }
  await addPitstopOnChain(carId, lap, tire, fuel);
});

// --------- MEV Simulation (mock) -----------
simulateAttackButton.addEventListener("click", ()=>{
  attackResult.textContent = "Detecting mempool anomalies…";
  attackResult.style.color = "#fff";
  setTimeout(()=>{
    const r = Math.random();
    if(r>0.5){
      attackResult.textContent = "🚨 Sandwich Attack Detected — relayer suggested: Flashbots";
      attackResult.style.color = "#ff4444";
    } else {
      attackResult.textContent = "✅ Transaction Protected: Private relayer used (simulated)";
      attackResult.style.color = "#22ff88";
    }
  },600);
});

// --------- fake live chart animation (mock) -----------
(function animateFakeChart(){
  // simple text replacement to create motion for video
  const el = document.getElementById("fakeChart");
  let n=0;
  setInterval(()=> {
    n = (n+Math.floor(Math.random()*10))%100;
    el.innerHTML = `<div style="width:${50 + n/2}% ;height:16px;background:linear-gradient(90deg,#ffcc00,#b80000)"></div>`;
  },600);
})();
